╔══════════════════════════════════════════════════════════════╗
║                 FORTNITE SOFTAIM + ESP v5.1                  ║
║                  SEASON 7 - UNDETECTED                       ║
╚══════════════════════════════════════════════════════════════╝

FEATURES:
---------
✓ Softaim (Legit Aimbot)
✓ Full ESP (Players, Loot, Vehicles)
✓ Radar Hack
✓ No Bloom / No Recoil
✓ Fast Farm
✓ FOV Changer

HOW TO USE:
-----------
1. Close Fortnite and Epic Games Launcher
2. Disable Windows Defender / Add exclusion
3. Run "FortniteLoader.exe" as Admin
4. Wait for "Ready" message
5. Open Fortnite from launcher
6. Press F5 in lobby to open menu

HOTKEYS:
--------
F5      - Menu
F6      - Aimbot Toggle
F7      - ESP Toggle
F8      - Radar Toggle
F12     - Panic Close

⚠️ WARNINGS:
- Spoofer recommended
- Don't use on main account first time
- Use at your own risk

Discord: discord.gg/fortnitehacks
