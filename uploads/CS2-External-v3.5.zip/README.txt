╔══════════════════════════════════════════════════════════════╗
║                     CS2 / CSGO EXTERNAL                      ║
║                   VAC UNDETECTED 2024                        ║
╚══════════════════════════════════════════════════════════════╝

FEATURES:
---------
✓ Legit Aimbot
✓ Rage Aimbot
✓ Full ESP (Enemies & Teammates)
✓ Triggerbot
✓ Bhop Script
✓ No Flash
✓ Radar Hack
✓ Skin Changer
✓ Rank Revealer

HOW TO USE:
-----------
1. Run "CSLoader.exe" as Administrator
2. Open CS2 or CSGO
3. Wait for "Loaded" notification
4. Press HOME to open menu

MENU TABS:
----------
• Legit - Smooth aimbot for MM
• Rage - Instant headshot (HvH)
• Visuals - ESP settings
• Misc - Bhop, No Flash, etc
• Skins - Change weapon skins

HOTKEYS:
--------
HOME    - Toggle Menu
F1      - Legit Aimbot
F2      - Rage Mode
F3      - Triggerbot
F4      - Bhop
INS     - Panic Key

⚠️ WARNING: Don't use on Prime accounts!
Works on: Faceit (with spoofer), ESEA (risky), MM (safe)

Discord: discord.gg/cs2cheats
