╔══════════════════════════════════════════════════════════════╗
║                    SYNAPSE X CRACKED v2.8                    ║
║                   FREE ROBLOX EXECUTOR                       ║
╚══════════════════════════════════════════════════════════════╝

FEATURES:
---------
✓ Full Lua Execution
✓ Script Hub Included
✓ Auto Execute
✓ Multi Instance
✓ Infinite Yield Support
✓ All Games Compatible

HOW TO USE:
-----------
1. Extract all files to a folder
2. Disable Windows Defender (REQUIRED)
3. Run "SynapseLoader.exe" as Administrator
4. Click "Inject" when Roblox is open
5. Paste scripts and click "Execute"

INCLUDED SCRIPTS:
-----------------
• Infinite Yield Admin
• Dark Dex Explorer
• ESP Universal
• Aimbot Universal
• Fly Hack
• Speed Hack
• Noclip

⚠️ IMPORTANT:
- Run as Admin ALWAYS
- Add folder to Defender exclusions
- Works on all Roblox games

Join our Discord: discord.gg/synapsefree
