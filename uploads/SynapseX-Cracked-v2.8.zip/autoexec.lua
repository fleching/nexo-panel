-- Synapse X Cracked Autoexec
-- This script runs automatically when injected

print("Synapse X Cracked Loaded!")
print("Version: 2.8.0")

-- Load Infinite Yield
-- loadstring(game:HttpGet("https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source"))()

-- Your custom scripts below:

