╔══════════════════════════════════════════════════════════════╗
║                    WURST+ CLIENT v7.4                        ║
║               MINECRAFT HACKED CLIENT 1.20.X                 ║
╚══════════════════════════════════════════════════════════════╝

FEATURES:
---------
✓ KillAura / Aimbot
✓ ESP / Tracers / Nametags
✓ Fly / Speed / NoFall
✓ Nuker / FastBreak
✓ Xray
✓ AutoFish / AutoMine
✓ Scaffold / Tower
✓ AntiKnockback
✓ ClickAura
✓ Criticals

HOW TO USE:
-----------
1. Run "WurstInstaller.exe"
2. It will auto-detect your Minecraft folder
3. Launch Minecraft with "Wurst" profile
4. Press RIGHT SHIFT to open menu

BYPASSES:
---------
✓ Hypixel (use Scaffold carefully)
✓ Mineplex
✓ CubeCraft
✓ All vanilla servers

KEYBINDS:
---------
RIGHT SHIFT - Open ClickGUI
R           - KillAura
X           - Fly
C           - Fullbright
G           - Xray

⚠️ NOTE: Some anticheats may detect. Use ALTs!

YouTube: @WurstClient
Discord: discord.gg/wurst
