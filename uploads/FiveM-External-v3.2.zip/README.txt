╔══════════════════════════════════════════════════════════════╗
║                    FIVEM EXTERNAL CHEAT v3.2                 ║
║                     UNDETECTED 2024/2025                     ║
╚══════════════════════════════════════════════════════════════╝

FEATURES:
---------
✓ Aimbot (Smooth, FOV configurable)
✓ ESP (Box, Skeleton, Names, Health)
✓ Triggerbot
✓ No Recoil / No Spread
✓ Speed Hack
✓ Teleport
✓ Vehicle Spawner
✓ God Mode

HOW TO USE:
-----------
1. Close FiveM if open
2. Run "Loader.exe" as Administrator
3. Wait for "Injected" message
4. Open FiveM and join any server
5. Press INSERT to open menu

HOTKEYS:
--------
INSERT  - Open/Close Menu
HOME    - Aimbot Toggle
END     - ESP Toggle
DELETE  - Panic Key (closes cheat)

⚠️ IMPORTANT:
- Disable Windows Defender before running
- Run as Administrator
- Works on all FiveM servers

Contact: @fivemcheats on Telegram
