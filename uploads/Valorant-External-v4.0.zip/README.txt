╔══════════════════════════════════════════════════════════════╗
║                  VALORANT EXTERNAL v4.0                      ║
║                   VANGUARD BYPASS 2024                       ║
╚══════════════════════════════════════════════════════════════╝

FEATURES:
---------
✓ Aimbot (Smooth, Humanized)
✓ Full ESP (Box, Skeleton, Health, Names)
✓ Triggerbot (Instant headshot)
✓ No Recoil
✓ Radar Hack
✓ Skin Changer (client-side)

HOW TO USE:
-----------
1. RESTART PC before using
2. Run "ValorantLoader.exe" as Admin BEFORE opening Valorant
3. Wait for green "Ready" message
4. Open Valorant
5. Press INSERT in-game

VANGUARD BYPASS:
----------------
This loader uses kernel-level bypass.
Vanguard cannot detect our driver.
HWID spoofer included.

HOTKEYS:
--------
INSERT  - Menu
HOME    - Aimbot
END     - ESP
DEL     - Triggerbot
F9      - Panic Key

⚠️ USE ON ALT ACCOUNT FIRST!
Riot has hardware bans.
Spoofer is auto-enabled.

Telegram: @valoranthacks_official
